import PersonalWebsite from './PersonalWebsite';

const Index = () => {
  return <PersonalWebsite />;
};

export default Index;
