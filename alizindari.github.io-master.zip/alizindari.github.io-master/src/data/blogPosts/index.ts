import { post1 } from './post1';
import { post2 } from './post2';
import { post3 } from './post3';
import { BlogPost } from './types';

export const blogPosts: BlogPost[] = [/*post1, post2, post3*/];

export type { BlogPost };
